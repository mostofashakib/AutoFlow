# HackRice-8-Team-Red-Raider-Website
A website created at HackRice8 for Project Portal that supports different compatibility and mobile usability.

• FrontEnd: HTML5, CSS3, JavaScript , jQuery, Bootstrap

• Backend: NodeJS, Express, .Tech domain, Restful routing

• APIs used: Google API.

Award: Best web design award at HackRice 8 at Rice University

Developed by Designed by Mostofa Adib Shakib

Website: https://team-red-raider-website.herokuapp.com/
